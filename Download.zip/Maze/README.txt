Bailey Thompson
Maze (1.2.1)
14 January 2017

The  user  is  first  introduced  to  a default grid, in which a file is created using file io. The user has an
option  of three buttons and two sliders on the bottom. When the clear button is pressed, the board is reset to
only  walls  and paths, when the generate button is pressed, a new board of specified size is created, and when
the  exit  button is pressed, the program exits. The size slider is a value between and including 2 to 30, when
the  generate  button  is  pressed,  the  size is thus reflected, if the user hovers over the slider, important
information  is  displayed  to  the  user. The time slider is between and including 0 to 1000 -- the time is in
milliseconds;  0  is instant -- the time slider is reflected immediately after it is changed, as with the other
slider  this one also displays important information if hovered over. The first click on the board is the start
position  and  is  in red. The second click is the end position in blue. A green cell will go from start to end
and  change  cell  once  per turn as specified by the time slider. Once the green cell reached the end, it will
display  the path taken. When generate is clicked, the progress in percentage is displayed next to the title of
the program.


If you do not have the Java 8 JRE, please follow these steps.
1. Go to this website: http://www.oracle.com/technetwork/java/javase/downloads/jre8-downloads-2133155.html
2. Accept the license agreement
3. Download the version that best suits your operating system
4. Wait for the download to be completed
5. Start the .jar file in the folder in which you found these instructions